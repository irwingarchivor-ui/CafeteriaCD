<?php
include("conexion.php");

// Solo permitimos eliminar mediante el envío de un formulario POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

if (!isset($_POST["id"]) || !ctype_digit((string)$_POST["id"])) {
    header("Location: index.php?eliminado=error");
    exit;
}

$id = (int) $_POST["id"];

$stmt = $conexion->prepare("DELETE FROM productos WHERE id_producto = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    $stmt->close();
    header("Location: index.php?eliminado=1");
    exit;
}

$stmt->close();
header("Location: index.php?eliminado=error");
exit;
?>
