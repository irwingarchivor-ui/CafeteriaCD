
document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.querySelector(".formulario");

    if (!formulario) return;

    const nombre = document.getElementById("nombre");
    const categoria = document.getElementById("categoria");
    const tamano = document.getElementById("tamano");
    const precio = document.getElementById("precio");
    const stock = document.getElementById("stock");
    const disponible = document.getElementById("disponible");

    formulario.addEventListener("submit", function (event) {
        if (!formulario.checkValidity()) {
            event.preventDefault();
            formulario.reportValidity();
            return;
        }

        const confirmar = confirm(
            "¿Estás seguro de que deseas guardar los cambios de este producto?"
        );

        if (!confirmar) {
            event.preventDefault();
        }
    });

    precio.addEventListener("input", function () {
        if (Number(precio.value) <= 0) {
            precio.setCustomValidity("El precio debe ser mayor que cero.");
        } else {
            precio.setCustomValidity("");
        }
    });

    stock.addEventListener("input", function () {
        if (stock.value < 0 || !Number.isInteger(Number(stock.value))) {
            stock.setCustomValidity("Ingresa una cantidad válida de productos.");
        } else {
            stock.setCustomValidity("");
        }
    });

    [nombre, categoria, tamano, precio, stock, disponible].forEach(function (campo) {
        campo.addEventListener("change", function () {
            campo.classList.add("modificado");
        });
    });
});
