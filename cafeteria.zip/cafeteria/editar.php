
<?php
include("conexion.php");

function mostrarError($mensaje) {
    echo "<!DOCTYPE html>
    <html lang='es'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Error</title>
        <link rel='stylesheet' href='css/editar.css'>
    </head>
    <body class='pagina-error'>
        <div class='contenedor-error'>
            <h2>" . htmlspecialchars($mensaje, ENT_QUOTES, "UTF-8") . "</h2>
            <a class='volver' href='index.php'>Volver a productos</a>
        </div>
    </body>
    </html>";
    exit;
}

$idRecibido = $_GET["id"] ?? $_POST["id_producto"] ?? "";

if (!ctype_digit((string)$idRecibido) || (int)$idRecibido < 1) {
    header("Location: index.php?error=1");
    exit;
}

$id = (int)$idRecibido;
$mensaje = "";

$nombres = [
    "Café americano", "Capuchino", "Latte",
    "Chocolate caliente", "Té", "Limonada",
    "Frappé", "Pastel de chocolate", "Dona", "Croissant"
];

$categorias = [
    "Café caliente", "Bebida fría", "Té", "Postre", "Panadería"
];

$tamanos = ["Normal", "Chico", "Mediano", "Grande", "Porción"];

$stmt = $conexion->prepare(
    "SELECT id_producto, nombre, categoria, tamano, precio, stock, disponible
     FROM productos WHERE id_producto = ?"
);

if (!$stmt) {
    mostrarError("No se pudo preparar la consulta: " . $conexion->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();

$stmt->bind_result(
    $idProducto,
    $nombreBD,
    $categoriaBD,
    $tamanoBD,
    $precioBD,
    $stockBD,
    $disponibleBD
);

if (!$stmt->fetch()) {
    $stmt->close();
    mostrarError("No se encontró el producto solicitado.");
}

$stmt->close();

$nombre = $nombreBD;
$categoria = $categoriaBD;
$tamano = $tamanoBD;
$precio = $precioBD;
$stock = $stockBD;
$disponible = $disponibleBD;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST["nombre"] ?? "";
    $categoria = $_POST["categoria"] ?? "";
    $tamano = $_POST["tamano"] ?? "";
    $precioTexto = $_POST["precio"] ?? "";
    $stockTexto = $_POST["stock"] ?? "";
    $disponibleTexto = $_POST["disponible"] ?? "";

    $valido = in_array($nombre, $nombres, true)
        && in_array($categoria, $categorias, true)
        && in_array($tamano, $tamanos, true)
        && is_numeric($precioTexto)
        && (float)$precioTexto > 0
        && filter_var($stockTexto, FILTER_VALIDATE_INT) !== false
        && (int)$stockTexto >= 0
        && in_array((string)$disponibleTexto, ["0", "1"], true);

    if ($valido) {
        $precio = (float)$precioTexto;
        $stock = (int)$stockTexto;
        $disponible = (int)$disponibleTexto;

        $stmt = $conexion->prepare(
            "UPDATE productos
             SET nombre = ?, categoria = ?, tamano = ?,
                 precio = ?, stock = ?, disponible = ?
             WHERE id_producto = ?"
        );

        if (!$stmt) {
            mostrarError("No se pudo preparar la actualización: " . $conexion->error);
        }

        $stmt->bind_param(
            "sssdiii",
            $nombre,
            $categoria,
            $tamano,
            $precio,
            $stock,
            $disponible,
            $id
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php?actualizado=1");
            exit;
        }

        $stmt->close();
        $mensaje = "No se pudieron guardar los cambios.";
    } else {
        $mensaje = "Verifica los datos del formulario.";
    }
}

function seleccionado($opcion, $actual) {
    return (string)$opcion === (string)$actual ? "selected" : "";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar producto | Mi Cafetería</title>

    <link rel="stylesheet" href="css/editar.css">
</head>

<script src="js/editar.js"></script>

<body>
<div class="contenedor">

    <header>
        <h1>☕ Mi Cafetería</h1>
        <p>Editar producto</p>
    </header>

    <section class="panel">
        <h2>Modificar información</h2>

        <?php if ($mensaje !== ""): ?>
            <div class="mensaje">
                <?= htmlspecialchars($mensaje, ENT_QUOTES, "UTF-8") ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="formulario">
            <input type="hidden" name="id_producto" value="<?= $id ?>">

            <div class="campo">
                <label for="nombre">Nombre</label>
                <select name="nombre" id="nombre" required>
                    <?php foreach ($nombres as $opcion): ?>
                        <option value="<?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>"
                            <?= seleccionado($opcion, $nombre) ?>>
                            <?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label for="categoria">Categoría</label>
                <select name="categoria" id="categoria" required>
                    <?php foreach ($categorias as $opcion): ?>
                        <option value="<?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>"
                            <?= seleccionado($opcion, $categoria) ?>>
                            <?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label for="tamano">Tamaño</label>
                <select name="tamano" id="tamano" required>
                    <?php foreach ($tamanos as $opcion): ?>
                        <option value="<?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>"
                            <?= seleccionado($opcion, $tamano) ?>>
                            <?= htmlspecialchars($opcion, ENT_QUOTES, "UTF-8") ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label for="precio">Precio ($)</label>
                <input type="number" name="precio" id="precio"
                       min="0.01" step="0.01"
                       value="<?= htmlspecialchars((string)$precio, ENT_QUOTES, "UTF-8") ?>"
                       required>
            </div>

            <div class="campo">
                <label for="stock">Stock</label>
                <input type="number" name="stock" id="stock"
                       min="0" step="1"
                       value="<?= (int)$stock ?>" required>
            </div>

            <div class="campo">
                <label for="disponible">¿Disponible?</label>
                <select name="disponible" id="disponible" required>
                    <option value="1" <?= seleccionado("1", $disponible) ?>>Sí</option>
                    <option value="0" <?= seleccionado("0", $disponible) ?>>No</option>
                </select>
            </div>

            <button type="submit" class="boton">Guardar cambios</button>
        </form>

        <a class="volver" href="index.php">Volver a productos</a>
    </section>

</div>
</body>
</html>

