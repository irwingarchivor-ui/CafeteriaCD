
<?php
include("conexion.php");

$mensaje = "";

if (isset($_GET["registrado"])) {
    $mensaje = "Producto registrado correctamente.";
} elseif (isset($_GET["actualizado"])) {
    $mensaje = "Producto actualizado correctamente.";
} elseif (isset($_GET["eliminado"])) {
    $mensaje = "Producto eliminado correctamente.";
} elseif (isset($_GET["error"])) {
    $mensaje = "Ocurrió un error al realizar la operación.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["registrar"])) {
    $nombre = $_POST["nombre"] ?? "";
    $categoria = $_POST["categoria"] ?? "";
    $tamano = $_POST["tamano"] ?? "";
    $precio = $_POST["precio"] ?? "";
    $stock = $_POST["stock"] ?? "";
    $disponible = $_POST["disponible"] ?? "";

    $nombres = [
        "Café americano", "Capuchino", "Latte",
        "Chocolate caliente", "Té", "Limonada",
        "Frappé", "Pastel de chocolate", "Dona", "Croissant"
    ];

    $categorias = [
        "Café caliente", "Bebida fría", "Té",
        "Postre", "Panadería"
    ];

    $tamanos = [
        "Normal", "Chico", "Mediano", "Grande", "Porción"
    ];

    $valido = in_array($nombre, $nombres, true)
        && in_array($categoria, $categorias, true)
        && in_array($tamano, $tamanos, true)
        && is_numeric($precio)
        && (float)$precio > 0
        && filter_var($stock, FILTER_VALIDATE_INT) !== false
        && (int)$stock >= 0
        && in_array((string)$disponible, ["0", "1"], true);

    if ($valido) {
        $precio = (float)$precio;
        $stock = (int)$stock;
        $disponible = (int)$disponible;

        $sql = "INSERT INTO productos
                (nombre, categoria, tamano, precio, stock, disponible)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conexion->prepare($sql);

        $stmt->bind_param(
            "sssdii",
            $nombre,
            $categoria,
            $tamano,
            $precio,
            $stock,
            $disponible
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php?registrado=1");
            exit;
        }

        $stmt->close();
        $mensaje = "Error al registrar el producto.";
    } else {
        $mensaje = "Verifica los datos ingresados.";
    }
}

$resultado = $conexion->query(
    "SELECT * FROM productos ORDER BY id_producto DESC"
);

if (!$resultado) {
    die("Error al consultar los productos: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Cafetería</title>

    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
<div class="contenedor">

    <header>
        <h1>☕ Mi Cafetería</h1>
        <p>Administración de productos e inventario</p>
    </header>

    <section class="panel">
        <h2>Registrar producto</h2>

        <?php if ($mensaje !== ""): ?>
            <div class="mensaje">
                <?= htmlspecialchars($mensaje, ENT_QUOTES, "UTF-8") ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="formulario">

            <div class="campo">
                <label for="nombre">Nombre del producto</label>
                <select id="nombre" name="nombre" required>
                    <option value="">Selecciona un producto</option>
                    <option value="Café americano">Café americano</option>
                    <option value="Capuchino">Capuchino</option>
                    <option value="Latte">Latte</option>
                    <option value="Chocolate caliente">Chocolate caliente</option>
                    <option value="Té">Té</option>
                    <option value="Limonada">Limonada</option>
                    <option value="Frappé">Frappé</option>
                    <option value="Pastel de chocolate">Pastel de chocolate</option>
                    <option value="Dona">Dona</option>
                    <option value="Croissant">Croissant</option>
                </select>
            </div>

            <div class="campo">
                <label for="categoria">Categoría</label>
                <select id="categoria" name="categoria" required>
                    <option value="">Selecciona una categoría</option>
                    <option value="Café caliente">Café caliente</option>
                    <option value="Bebida fría">Bebida fría</option>
                    <option value="Té">Té</option>
                    <option value="Postre">Postre</option>
                    <option value="Panadería">Panadería</option>
                </select>
            </div>

            <div class="campo">
                <label for="tamano">Tamaño</label>
                <select id="tamano" name="tamano" required>
                    <option value="Normal">Normal</option>
                    <option value="Chico">Chico</option>
                    <option value="Mediano">Mediano</option>
                    <option value="Grande">Grande</option>
                    <option value="Porción">Porción</option>
                </select>
            </div>

            <div class="campo">
                <label for="precio">Precio de venta ($)</label>
                <input type="number" id="precio" name="precio"
                       min="0.01" step="0.01"
                       placeholder="Ej. 35.00" required>
            </div>

            <div class="campo">
                <label for="stock">Cantidad en inventario</label>
                <input type="number" id="stock" name="stock"
                       min="0" step="1"
                       placeholder="Ej. 20" required>
            </div>

            <div class="campo">
                <label for="disponible">¿Está disponible?</label>
                <select id="disponible" name="disponible" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>

            <button type="submit" name="registrar" value="1" class="boton">
                Registrar producto
            </button>

        </form>
    </section>

    <section class="panel">
        <h2>Productos registrados</h2>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Categoría</th>
                        <th>Tamaño</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Disponible</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                <?php if ($resultado->num_rows > 0): ?>

                    <?php while ($producto = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?= (int)$producto["id_producto"] ?></td>

                        <td>
                            <?= htmlspecialchars($producto["nombre"], ENT_QUOTES, "UTF-8") ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($producto["categoria"], ENT_QUOTES, "UTF-8") ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($producto["tamano"], ENT_QUOTES, "UTF-8") ?>
                        </td>

                        <td>
                            $<?= number_format((float)$producto["precio"], 2) ?>
                        </td>

                        <td><?= (int)$producto["stock"] ?></td>

                        <td class="estado <?= (int)$producto["disponible"] === 1 ? 'si' : 'no' ?>">
                            <?= (int)$producto["disponible"] === 1 ? "Sí" : "No" ?>
                        </td>

                        <td>
                            <div class="acciones">

                                <a class="btn-editar"
                                   href="editar.php?id=<?= (int)$producto["id_producto"] ?>">
                                    Editar
                                </a>

                                <form class="form-eliminar"
                                      method="POST"
                                      action="eliminar.php"
                                      onsubmit="return confirm('¿Seguro que deseas eliminar este producto?');">

                                    <input type="hidden" name="id"
                                           value="<?= (int)$producto["id_producto"] ?>">

                                    <button type="submit" class="btn-eliminar">
                                        Eliminar
                                    </button>

                                </form>

                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="8">Todavía no hay productos registrados.</td>
                    </tr>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
</body>
</html>
